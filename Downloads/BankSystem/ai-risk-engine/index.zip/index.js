/**
 * AI Risk Engine — Secure Smart Banking Platform
 * ------------------------------------------------
 * النسخة الكاملة والجاهزة — متصلة فعليًا بقاعدة البيانات (PostgreSQL/RDS)
 * وببعت تنبيهات فعلية على SNS.
 */

const { Pool } = require("pg");
const { SNSClient, PublishCommand } = require("@aws-sdk/client-sns");

// ============================================================
// الاتصال بقاعدة البيانات — بيتقرا من environment variable
// اسمها DATABASE_URL (نفس الاسم المستخدم في الـ Backend بالظبط)
// شكلها: postgresql://username:password@endpoint:5432/banking
// ============================================================
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // مطلوبة عادة للاتصال بـ RDS من بره الشبكة الداخلية أحيانًا
  max: 2, // Lambda مش محتاجة connections كتير زي سيرفر عادي
});

const sns = new SNSClient({});
const ALERT_TOPIC_ARN = process.env.SECURITY_ALERT_TOPIC_ARN;

exports.handler = async (event) => {
  // إنشاء جدول security_logs تلقائياً لو لم يكن موجوداً لتجنب أي أخطاء
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS security_logs (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255),
        event_type VARCHAR(100),
        is_suspicious BOOLEAN,
        risk_score INT,
        details TEXT,
        device_fingerprint VARCHAR(255),
        country VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
  } catch (dbSetupError) {
    console.error("Error creating table automatically:", dbSetupError);
  }

  const message = JSON.parse(event.Records[0].Sns.Message);

  let result;
  if (message.type === "login") {
    result = await analyzeLogin(message);
  } else if (message.type === "transaction") {
    result = await analyzeTransaction(message);
  } else {
    return { statusCode: 400, body: "Unknown event type" };
  }

  await logSecurityEvent(message, result);

  if (result.suspicious) {
    await sns.send(new PublishCommand({
      TopicArn: ALERT_TOPIC_ARN,
      Subject: `تنبيه أمني: ${message.type === "login" ? "محاولة دخول مشبوهة" : "عملية تحويل مشبوهة"}`,
      Message: JSON.stringify({
        userId: message.userId,
        type: message.type,
        riskScore: result.riskScore,
        reasons: result.reasons,
        timestamp: new Date().toISOString(),
      }, null, 2),
    }));
  }

  return { statusCode: 200, body: JSON.stringify(result) };
};

// ============================================================
// 1) تحليل عملية الـ Login
// ============================================================
async function analyzeLogin(data) {
  const reasons = [];
  let riskScore = 0;

  const lastLogin = await getLastSuccessfulLogin(data.userId);
  if (lastLogin && lastLogin.country && lastLogin.country !== data.country) {
    reasons.push(`تغيّر الدولة: من ${lastLogin.country} إلى ${data.country}`);
    riskScore += 40;
  }

  const knownDevice = await isKnownDevice(data.userId, data.deviceFingerprint);
  if (!knownDevice) {
    reasons.push("جهاز غير معروف من قبل لهذا العميل");
    riskScore += 25;
  }

  const recentFailedAttempts = await countRecentFailedLogins(data.userId, 10);
  if (recentFailedAttempts >= 5) {
    reasons.push(`${recentFailedAttempts} محاولات دخول فاشلة خلال آخر 10 دقائق`);
    riskScore += 50;
  }

  const isUnusualHour = await isUnusualLoginHour(data.userId, data.timestamp);
  if (isUnusualHour) {
    reasons.push("توقيت دخول غير معتاد لهذا العميل");
    riskScore += 15;
  }

  return { suspicious: riskScore >= 40, riskScore, reasons };
}

// ============================================================
// 2) تحليل عملية التحويل المالي
// ============================================================
async function analyzeTransaction(data) {
  const reasons = [];
  let riskScore = 0;

  const avgAmount = await getAverageTransactionAmount(data.userId);
  if (avgAmount > 0 && data.amount > avgAmount * 5) {
    reasons.push(`المبلغ (${data.amount}) أكبر من 5 أضعاف متوسط العميل (${avgAmount.toFixed(2)})`);
    riskScore += 45;
  }

  const transferredBefore = await hasTransferredToAccountBefore(data.userId, data.toAccount);
  if (!transferredBefore) {
    reasons.push("أول تحويل لهذا الحساب المستقبل");
    riskScore += 15;
  }

  const recentTransferCount = await countRecentTransfers(data.userId, 10);
  if (recentTransferCount >= 4) {
    reasons.push(`${recentTransferCount} تحويلات خلال آخر 10 دقائق`);
    riskScore += 35;
  }

  const ABSOLUTE_LIMIT = 100000;
  if (data.amount > ABSOLUTE_LIMIT) {
    reasons.push(`المبلغ يتجاوز الحد الأقصى المطلق (${ABSOLUTE_LIMIT})`);
    riskScore += 30;
  }

  return { suspicious: riskScore >= 40, riskScore, reasons };
}

// ============================================================
// دوال قاعدة البيانات — شغّالة فعليًا بـ pg
// ============================================================

async function getLastSuccessfulLogin(userId) {
  const { rows } = await pool.query(
    `SELECT country FROM security_logs
     WHERE user_id = $1 AND event_type = 'login' AND is_suspicious = false
     ORDER BY created_at DESC LIMIT 1 OFFSET 1`,
    [userId]
  );
  return rows[0] || null;
}

async function isKnownDevice(userId, deviceFingerprint) {
  const { rows } = await pool.query(
    `SELECT COUNT(*) as count FROM security_logs
     WHERE user_id = $1 AND device_fingerprint = $2`,
    [userId, deviceFingerprint]
  );
  return rows[0].count > 0;
}

async function countRecentFailedLogins(userId, minutes) {
  const { rows } = await pool.query(
    `SELECT COUNT(*) as count FROM security_logs
     WHERE user_id = $1 AND event_type = 'login_failed'
     AND created_at > NOW() - INTERVAL '${minutes} minutes'`,
    [userId]
  );
  return parseInt(rows[0].count, 10);
}

async function isUnusualLoginHour(userId, timestamp) {
  const hour = new Date(timestamp).getHours();
  const { rows } = await pool.query(
    `SELECT COUNT(*) as count FROM security_logs
     WHERE user_id = $1 AND event_type = 'login' AND is_suspicious = false
     AND EXTRACT(HOUR FROM created_at) BETWEEN $2 AND $3`,
    [userId, Math.max(0, hour - 2), Math.min(23, hour + 2)]
  );
  return parseInt(rows[0].count, 10) === 0;
}

async function getAverageTransactionAmount(userId) {
  const { rows } = await pool.query(
    `SELECT AVG(amount) as avg_amount FROM transactions
     WHERE from_account IN (SELECT id FROM accounts WHERE user_id = $1)
     AND status = 'completed'`,
    [userId]
  );
  return parseFloat(rows[0].avg_amount) || 0;
}

async function hasTransferredToAccountBefore(userId, toAccount) {
  const { rows } = await pool.query(
    `SELECT COUNT(*) as count FROM transactions
     WHERE from_account IN (SELECT id FROM accounts WHERE user_id = $1)
     AND to_account = $2`,
    [userId, toAccount]
  );
  return rows[0].count > 0;
}

async function countRecentTransfers(userId, minutes) {
  const { rows } = await pool.query(
    `SELECT COUNT(*) as count FROM transactions
     WHERE from_account IN (SELECT id FROM accounts WHERE user_id = $1)
     AND created_at > NOW() - INTERVAL '${minutes} minutes'`,
    [userId]
  );
  return parseInt(rows[0].count, 10);
}

async function logSecurityEvent(message, result) {
  await pool.query(
    `INSERT INTO security_logs
      (user_id, event_type, is_suspicious, risk_score, details, device_fingerprint, country, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
    [
      message.userId, 
      message.type, 
      result.suspicious, 
      result.riskScore, 
      JSON.stringify(result.reasons),
      message.deviceFingerprint || null,
      message.country || null
    ]
  );
}